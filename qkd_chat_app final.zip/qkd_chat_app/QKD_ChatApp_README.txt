BANG BANG SKEET SKEET NIGGAS. I FINISH THE PROJECT AND SAVED EVERYONES ASSES LOLL

# QKD LAN Chat App

A GUI-based secure chat app that allows two users on the same local network to:
- Establish a shared secret key using a simulated **Quantum Key Distribution (BB84 protocol)**
- Encrypt messages using **AES**
- Communicate securely over sockets with a user-friendly GUI

---

## 🔍 Why This Project Was Made

This project was built to demonstrate a secure communication system that uses Quantum Key Distribution (QKD) for key exchange and AES encryption for message confidentiality. It aims to show how future-ready cryptographic techniques can be applied in simple peer-to-peer applications over LAN networks.

---

## ✅ Problem It Solves

Traditional encryption relies on mathematical complexity, which can be broken with enough computing power. QKD leverages the laws of quantum physics to exchange keys securely — making eavesdropping detectable and communication more secure.

---

## 🔐 Why AES if we have QKD?

**QKD provides a secure key exchange**—not encryption. Once the key is shared securely using QKD, 
**AES (or any symmetric cipher)** is used to encrypt the actual messages. 
QKD just ensures the key was never intercepted or tampered with.

---

## 🧪 How to Use (Everyone in the group try this)

1. Both users unzip and run the script.
2. One user selects `host`, the other selects `client` and inputs the IP of the host.
3. Chat securely after QKD key generation.

---

## ⚙️ The Only Requirement

```
pip install pycryptodome
```

---

## ▶️ How to Run (Cuz Dhinkar will ask this question)

Open VS Code or any Python IDE and run `network_chat.py`

---

## ❓ Common Panel Questions & Suggested Answers

### 1. What is the main goal of your project?
> To build a secure LAN chat system where encryption keys are exchanged using quantum principles (QKD) instead of traditional methods.

### 2. Why did you still use AES if you implemented QKD?
> QKD helps us securely share a symmetric key, but it doesn’t encrypt data. AES is still used to encrypt the actual chat messages.

### 3. How does your implementation simulate QKD?
> We simulate the BB84 protocol using random bit and basis generation between two parties. After transmission and basis comparison, we derive a shared key.

### 4. Why use sockets and Tkinter?
> Sockets allow us to establish LAN communication. Tkinter was chosen for its simplicity and ease of building a GUI that makes the chat application interactive.

### 5. What makes this project different or innovative?
> Unlike normal chat apps, this project integrates QKD to mimic post-quantum key exchange. It introduces advanced cybersecurity principles in a beginner-friendly way.

### 6. Can this be scaled for real-world use?
> Real-world QKD needs quantum hardware (e.g., photon detectors), but this simulation is useful for training, research, and proof-of-concept applications.

### 7. What challenges did you face?
> - Maintaining GUI responsiveness during socket communication  
> - Synchronizing QKD steps between two parties  
> - Ensuring encryption/decryption remained reliable  

### 8. What improvements can be made in the future?
> - Add authentication before key exchange  
> - Integrate with real quantum simulators or hardware  
> - Add support for file transfer with QKD-secured keys

