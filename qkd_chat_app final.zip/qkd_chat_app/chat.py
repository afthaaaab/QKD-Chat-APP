from qkd import generate_key, measure, sift_keys
from encryption import encrypt, decrypt

def simulate_qkd():
    sender_basis, sender_bits = generate_key()
    receiver_basis, _ = generate_key()
    measured = measure(sender_bits, sender_basis, receiver_basis)
    shared_key_bits = sift_keys(sender_basis, receiver_basis, sender_bits, measured)
    key = ''.join([str(bit) for bit in shared_key_bits])
    return key.ljust(16, '0')  # Pad if less than 16 chars

def chat():
    print("Quantum Key Distribution in progress...")
    key = simulate_qkd()
    print(f"Shared AES key: {key}")

    while True:
        msg = input("You: ")
        enc = encrypt(msg, key)
        print(f"Encrypted: {enc}")
        print(f"Decrypted: {decrypt(enc, key)}\n")

if __name__ == "__main__":
    chat()