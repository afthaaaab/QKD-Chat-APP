from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64

def get_cipher(key):
    return AES.new(bytes(key, 'utf-8'), AES.MODE_ECB)

def encrypt(message, key):
    cipher = get_cipher(key)
    return base64.b64encode(cipher.encrypt(pad(message.encode(), 16))).decode()

def decrypt(ciphertext, key):
    cipher = get_cipher(key)
    return unpad(cipher.decrypt(base64.b64decode(ciphertext)), 16).decode()