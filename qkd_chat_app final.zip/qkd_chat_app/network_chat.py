import tkinter as tk
from tkinter import simpledialog, scrolledtext
import socket
import threading
from qkd import generate_key, measure, sift_keys
from encryption import encrypt, decrypt

HOST = ""
PORT = 65432

class ChatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("QKD LAN Chat")
        self.root.geometry("600x500")
        self.root.configure(bg="#1e1e2f")

        self.chat_area = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=70, height=20, bg="#252539", fg="white")
        self.chat_area.pack(pady=10)
        self.chat_area.config(state='disabled')

        self.msg_entry = tk.Entry(root, width=60, bg="#2e2e42", fg="white", insertbackground='white')
        self.msg_entry.pack(pady=5)
        self.msg_entry.bind("<Return>", self.send_message)

        self.send_button = tk.Button(root, text="Send", command=self.send_message, bg="#4e4e6a", fg="white")
        self.send_button.pack()

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.key = ""

        self.role = simpledialog.askstring("Role", "Enter role (host/client):").lower()
        if self.role == "host":
            self.start_server()
        else:
            self.target_ip = simpledialog.askstring("Connect", "Enter friend's IP address:")
            self.start_client()

    def simulate_qkd_host(self, conn):
        sender_basis, sender_bits = generate_key()
        conn.sendall(",".join(sender_basis).encode())
        conn.recv(1024)  # wait
        conn.sendall(",".join([str(b) for b in sender_bits]).encode())

        receiver_basis = conn.recv(1024).decode().split(",")
        receiver_bits = measure(sender_bits, sender_basis, receiver_basis)
        conn.sendall(",".join([str(b) for b in receiver_bits]).encode())

        shared_key_bits = sift_keys(sender_basis, receiver_basis, sender_bits, receiver_bits)
        key = ''.join([str(bit) for bit in shared_key_bits]).ljust(16, '0')
        return key

    def simulate_qkd_client(self):
        sender_basis = self.sock.recv(1024).decode().split(",")
        self.sock.sendall("ACK".encode())
        sender_bits = [int(b) for b in self.sock.recv(1024).decode().split(",")]
        receiver_basis, _ = generate_key()
        self.sock.sendall(",".join(receiver_basis).encode())
        receiver_bits = [int(b) for b in self.sock.recv(1024).decode().split(",")]
        shared_key_bits = sift_keys(sender_basis, receiver_basis, sender_bits, receiver_bits)
        key = ''.join([str(bit) for bit in shared_key_bits]).ljust(16, '0')
        return key

    def start_server(self):
        threading.Thread(target=self.accept_connection, daemon=True).start()

    def accept_connection(self):
        self.sock.bind((HOST, PORT))
        self.sock.listen()
        self.chat_area.config(state='normal')
        self.chat_area.insert(tk.END, "Waiting for client to connect...")
        self.chat_area.config(state='disabled')

        conn, _ = self.sock.accept()
        self.conn = conn
        self.key = self.simulate_qkd_host(conn)
        self.show_key()
        threading.Thread(target=self.receive_messages_server, daemon=True).start()

    def start_client(self):
        self.sock.connect((self.target_ip, PORT))
        self.key = self.simulate_qkd_client()
        self.show_key()
        threading.Thread(target=self.receive_messages_client, daemon=True).start()

    def show_key(self):
        self.chat_area.config(state='normal')
        self.chat_area.insert(tk.END, f"QKD Shared Key: {self.key}")
        self.chat_area.config(state='disabled')

    def send_message(self, event=None):
        msg = self.msg_entry.get()
        if msg:
            enc = encrypt(msg, self.key)
            try:
                if self.role == "host":
                    self.conn.sendall(enc.encode())
                else:
                    self.sock.sendall(enc.encode())
                self.chat_area.config(state='normal')
                self.chat_area.insert(tk.END, f"You: {msg} Encrypted: {enc}")
                self.chat_area.config(state='disabled')
                self.msg_entry.delete(0, tk.END)
            except:
                self.chat_area.insert(tk.END, "Connection lost.")

    def receive_messages_server(self):
        while True:
            try:
                msg = self.conn.recv(1024).decode()
                dec = decrypt(msg, self.key)
                self.chat_area.config(state='normal')
                self.chat_area.insert(tk.END, f"Friend: {dec}")
                self.chat_area.config(state='disabled')
            except:
                break

    def receive_messages_client(self):
        while True:
            try:
                msg = self.sock.recv(1024).decode()
                dec = decrypt(msg, self.key)
                self.chat_area.config(state='normal')
                self.chat_area.insert(tk.END, f"Friend: {dec}")
                self.chat_area.config(state='disabled')
            except:
                break

if __name__ == "__main__":
    root = tk.Tk()
    app = ChatApp(root)
    root.mainloop()