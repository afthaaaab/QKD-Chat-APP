import random

def generate_key(length=16):
    basis = [random.choice(['Z', 'X']) for _ in range(length)]
    bits = [random.choice([0, 1]) for _ in range(length)]
    return basis, bits

def measure(bits, sender_basis, receiver_basis):
    return [bit if sender_basis[i] == receiver_basis[i] else random.choice([0,1]) 
            for i, bit in enumerate(bits)]

def sift_keys(sender_basis, receiver_basis, sender_bits, receiver_bits):
    key = [sender_bits[i] for i in range(len(sender_basis)) if sender_basis[i] == receiver_basis[i]]
    return key[:16]  # limit to 16 bits